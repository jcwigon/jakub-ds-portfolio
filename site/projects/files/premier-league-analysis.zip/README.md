# ⚽ Analiza statystyk Premier League 2021–2025

📌 **Cel projektu:**  
Celem jest analiza danych meczowych z Premier League z lat 2021–2025. Projekt łączy statystyki z kilku sezonów, tworzy wizualizacje oraz dostarcza wniosków opartych na danych.

---

## 📊 Analizowane statystyki

Projekt analizuje kluczowe wskaźniki meczowe:

- ⚽ Liczba goli (średnia na sezon, na drużynę, porównania sezonów)
- 🎯 Strzały (średnie, skuteczność, dom vs wyjazd)
- 📈 Wskaźnik xG (expected goals – szacowane gole)
- 🚩 Kartki (żółte, czerwone)
- 🏆 Udział zwycięstw gospodarzy, gości i remisów

---

## 🛠️ Jak uruchomić projekt

1. **Zainstaluj wymagane biblioteki:**
   ```bash
   pip install -r requirements.txt
